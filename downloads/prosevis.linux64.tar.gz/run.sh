#!/bin/bash
export PATH=.:$PATH && java -Xmx1024m -jar prosevis.jar
